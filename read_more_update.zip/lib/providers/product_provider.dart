// lib/providers/product_provider.dart
import 'package:flutter/foundation.dart';
import 'package:flutter_application_1/models/product.dart';
import 'package:flutter_application_1/services/api_services.dart';


class ProductProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Product> _products = [];
  int _currentPage = 1;
  bool _isLoading = false;
  bool _hasMore = true;

  List<Product> get products => _products;
  bool get isLoading => _isLoading;
  bool get hasMore => _hasMore;

  Future<void> fetchProducts() async {
    if (_isLoading || !_hasMore) return;

    _isLoading = true;
    notifyListeners();

    try {
      final newProducts = await _apiService.fetchProducts(_currentPage);
      
      if (newProducts.isEmpty) {
        _hasMore = false;
      } else {
        _products.addAll(newProducts);
        _currentPage++;
      }
    } catch (e) {
      // Handle error
      debugPrint('Error fetching products: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void refreshProducts() {
    _products.clear();
    _currentPage = 1;
    _hasMore = true;
    fetchProducts();
  }
}