// lib/screens/product_list_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/product.dart';
import 'package:flutter_application_1/providers/product_provider.dart';
import 'package:flutter_application_1/screens/product_details.dart';
import 'package:provider/provider.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({Key? key}) : super(key: key);

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final productProvider = Provider.of<ProductProvider>(
      context,
      listen: false,
    );
    productProvider.fetchProducts();

    _scrollController.addListener(_scrollListener);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.offset >=
            _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      final productProvider = Provider.of<ProductProvider>(
        context,
        listen: false,
      );
      productProvider.fetchProducts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Products')),
      body: Consumer<ProductProvider>(
        builder: (context, productProvider, child) {
          if (productProvider.products.isEmpty && productProvider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          return RefreshIndicator(
            onRefresh: () async {
              productProvider.refreshProducts();
            },
            child: ListView.builder(
              controller: _scrollController,
              itemCount:
                  productProvider.products.length +
                  (productProvider.hasMore ? 1 : 0),
              itemBuilder: (context, index) {
                if (index < productProvider.products.length) {
                  final product = productProvider.products[index];
                  return _buildProductItem(product);
                } else {
                  return _buildLoader(productProvider);
                }
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductItem(Product product) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: ListTile(
        leading: Image.network(
          product.image,
          width: 50,
          height: 50,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => const Icon(Icons.error),
        ),
        title: Text(product.title),
        subtitle: Text('\$${product.price.toStringAsFixed(2)}'),
        trailing: Text('${product.rating.rate} ⭐'),
        onTap: () {
          // Navigate to product detail
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProductDetailScreen(product: product),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoader(ProductProvider productProvider) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: productProvider.hasMore
            ? const CircularProgressIndicator()
            : const Text('No more products'),
      ),
    );
  }
}
