


import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/product_list_screen.dart';
import 'package:flutter_application_1/providers/product_provider.dart';
import 'package:provider/provider.dart';

class ProductHomeProvider extends StatelessWidget {
  const ProductHomeProvider({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ProductProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primarySwatch: Colors.teal),
        home: const ProductListScreen(),
      ),
    );
  }
}