import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/product.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({required this.product, super.key});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20.0),
          Padding(
            padding: EdgeInsetsGeometry.all(8.0),
            child: Text('Product Detail Page...'),
          ),

          SizedBox(height: 20.0),

          Padding(
            padding: EdgeInsetsGeometry.all(8.0),
            child: Text(widget.product.title),
          ),

          SizedBox(height: 20.0),

          Padding(
            padding: EdgeInsetsGeometry.all(8.0),
            child: Text(widget.product.price.toString()),
          ),

          SizedBox(height: 20.0),

          Padding(
            padding: EdgeInsetsGeometry.all(8),
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Back to Product List '),
            ),
          ),
        ],
      ),
    );
  }
}
